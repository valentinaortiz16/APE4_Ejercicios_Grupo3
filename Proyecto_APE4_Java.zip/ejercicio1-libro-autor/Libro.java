/**
 * Clase Libro: tiene un atributo de tipo Autor (objeto como atributo).
 */
public class Libro {
    // Atributos
    private String titulo;
    private int anio;
    private Autor autor; // objeto como atributo

    // Constructor
    public Libro(String titulo, int anio, Autor autor) {
        this.titulo = titulo;
        this.anio = anio;
        this.autor = autor;
    }

    // Muestra el título, el año y el nombre del autor
    public void mostrarInformacion() {
        System.out.println("Título: " + titulo);
        System.out.println("Año: " + anio);
        System.out.println("Autor: " + autor.getNombre());
        System.out.println("-----------------------------");
    }
}
