/**
 * Ejercicio 1: Libro y Autor.
 */
public class Main {
    public static void main(String[] args) {
        // Se crean los autores
        Autor autor1 = new Autor("Gabriel García Márquez", "Colombiana");
        Autor autor2 = new Autor("Jorge Icaza", "Ecuatoriana");

        // Se crean los 2 libros
        Libro libro1 = new Libro("Cien años de soledad", 1967, autor1);
        Libro libro2 = new Libro("Huasipungo", 1934, autor2);

        // Se muestra la información de cada libro
        libro1.mostrarInformacion();
        libro2.mostrarInformacion();
    }
}
