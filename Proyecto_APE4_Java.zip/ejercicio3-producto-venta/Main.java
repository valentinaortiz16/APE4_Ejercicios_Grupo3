/**
 * Ejercicio 3: Producto y Venta.
 */
public class Main {
    public static void main(String[] args) {
        Producto laptop = new Producto("Laptop", 650.50, 10);

        System.out.println("--- Estado inicial ---");
        laptop.mostrarProducto();

        // Venta válida
        System.out.println("\n--- Venta de 3 unidades ---");
        Venta venta1 = new Venta(3);
        venta1.aplicar(laptop);
        laptop.mostrarProducto();

        // Venta que supera el stock
        System.out.println("\n--- Venta de 20 unidades ---");
        Venta venta2 = new Venta(20);
        venta2.aplicar(laptop);
        laptop.mostrarProducto();
    }
}
