/**
 * Ejercicio 4: Transferencias.
 */
public class Main {
    public static void main(String[] args) {
        Cuenta cuenta1 = new Cuenta("Valeria Ortiz", 500.0);
        Cuenta cuenta2 = new Cuenta("Mateo Salazar", 100.0);

        System.out.println("--- Saldos iniciales ---");
        cuenta1.mostrarCuenta();
        cuenta2.mostrarCuenta();

        // Transferencia válida
        System.out.println("\n--- Transferencia válida ($200) ---");
        cuenta1.transferir(cuenta2, 200.0);

        // Transferencia que falla
        System.out.println("\n--- Transferencia que falla ($1000) ---");
        cuenta1.transferir(cuenta2, 1000.0);

        System.out.println("\n--- Saldos finales ---");
        cuenta1.mostrarCuenta();
        cuenta2.mostrarCuenta();
    }
}
